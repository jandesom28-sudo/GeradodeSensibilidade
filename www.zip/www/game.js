  1/* game.js */

document.addEventListener('DOMContentLoaded', () => {
    const generateButton = document.getElementById('generate-button');
    const activatePremiumButton = document.getElementById('activate-premium');
    const generateUltraButton = document.getElementById('generate-ultra-button');
    const resultArea = document.getElementById('result-area');
    const ultraResultArea = document.getElementById('ultra-result-area'); 
    const premiumKeyInput = document.getElementById('premium-key');
    const deviceSelect = document.getElementById('device-select');
    const gameNameInput = document.getElementById('game-name');
    const ultraPremiumSection = document.getElementById('ultra-premium-section'); 

    // Chave de acesso Premium
    const PREMIUM_KEY = 'JANDERSON_PREMIUM';

    // Função auxiliar para gerar um número aleatório entre min e max (inclusivo)
    const getRandomSensibility = (min, max) => {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    };

    // --- LÓGICA DE GERAÇÃO NORMAL ---
    generateButton.addEventListener('click', () => {
        const device = deviceSelect.value;
        const game = gameNameInput.value || 'FREE FIRE (Simulação)';
        
        if (device === 'default') {
            resultArea.innerHTML = '⚠️ Por favor, selecione seu dispositivo.';
            return;
        }

        const geral = getRandomSensibility(100, 200);
        const pontoVermelho = getRandomSensibility(90, 180);
        const mira2x = getRandomSensibility(100, 200);
        const mira4x = getRandomSensibility(80, 150);
        const miraAWM = getRandomSensibility(10, 80); 

        resultArea.style.backgroundColor = '#006400';
        resultArea.style.color = '#FFFFFF';
        
        resultArea.innerHTML = `
            <strong style="color: #FFD700;">✅ CONFIGURAÇÃO OTIMIZADA!</strong><br>
            <hr style="border-color: rgba(255, 255, 255, 0.3);">
            Jogo: <strong>${game.toUpperCase()}</strong><br>
            Dispositivo: ${device.toUpperCase()}<br>
            
            <br>
            <h3>AJUSTES DE SENSIBILIDADE (Máx. 200):</h3>
            <ul>
                <li><strong>GERAL:</strong> ${geral}%</li>
                <li><strong>MIRA PONTO VERMELHO:</strong> ${pontoVermelho}%</li>
                <li><strong>MIRA 2X:</strong> ${mira2x}%</li>
                <li><strong>MIRA 4X:</strong> ${mira4x}%</li>
                <li><strong>MIRA AWM:</strong> ${miraAWM}%</li>
            </ul>
        `;
    });

    // --- LÓGICA DE ATIVAÇÃO PREMIUM ---
    activatePremiumButton.addEventListener('click', () => {
        const key = premiumKeyInput.value.trim();
        
        if (key === PREMIUM_KEY) {
            alert('🎉 Chave Premium ativada com sucesso! Acesso liberado às Configurações Ultra-Poderosas!');
            premiumKeyInput.style.backgroundColor = '#103010';
            
            ultraPremiumSection.classList.remove('hidden'); 
            
            premiumKeyInput.disabled = true;
            activatePremiumButton.disabled = true;

        } else if (key) {
            alert('❌ Chave de Acesso Premium inválida. Tente novamente.');
            premiumKeyInput.style.backgroundColor = '#301010';
        } else {
            alert('Insira uma chave para tentar ativar o Premium.');
        }
    });

    // --- LÓGICA DE GERAÇÃO ULTRA-PREMIUM ---
    generateUltraButton.addEventListener('click', () => {
        const game = gameNameInput.value || 'FREE FIRE (Ultra)';

        const ultraGeral = getRandomSensibility(180, 200);
        const ultraPontoVermelho = getRandomSensibility(150, 200);
        const ultraMira2x = getRandomSensibility(180, 200);
        const ultraMira4x = getRandomSensibility(120, 180);
        const ultraMiraAWM = getRandomSensibility(50, 100); 

        ultraResultArea.innerHTML = `
            <strong style="color: gold;">🔥 SENSIBILIDADE MÁXIMA PREMIUM ATIVADA!</strong><br>
            <hr style="border-color: rgba(255, 255, 255, 0.3);">
            Jogo: <strong>${game.toUpperCase()}</strong><br>
            
            <br>
            <h3>🚀 AJUSTES ULTRA-PODEROSOS:</h3>
            <ul>
                <li><strong>GERAL:</strong> ${ultraGeral}%</li>
                <li><strong>MIRA PONTO VERMELHO:</strong> ${ultraPontoVermelho}%</li>
                <li><strong>MIRA 2X:</strong> ${ultraMira2x}%</li>
                <li><strong>MIRA 4X:</strong> ${ultraMira4x}%</li>
                <li><strong>MIRA AWM:</strong> ${ultraMiraAWM}%</li>
                <li>**Bônus:** Recomendado DPI acima de 800.</li>
            </ul>
        `;
    });
});
